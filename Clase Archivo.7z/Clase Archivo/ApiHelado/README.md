# APIREST-PHP-POO-JWT-MIDDLEWARE-Documentar
API REST  en PHP con SlimFramework, POO + JSON Web Token + MiddleWare

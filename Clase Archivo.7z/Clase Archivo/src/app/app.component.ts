import { ParsedResponseHeaders } from 'ng2-file-upload/file-upload/file-uploader.class';
import { FileItem } from 'ng2-file-upload/file-upload/file-item.class';
import { FileUploader } from 'ng2-file-upload';

import { Component } from '@angular/core';
const URL ="http://localhost:8080/ApiHelado/archivo/";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public uploader:FileUploader = new FileUploader({url: URL});
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;
 
  constructor(){
    this.uploader.onSuccessItem =  (item : FileItem, response : string, status : number,header : ParsedResponseHeaders)=>
    {
      console.log(response);
    }
  }

  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }
 
  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }
}
